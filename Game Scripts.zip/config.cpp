class CfgPatches
{
	class TIOW_New_Headgear
	{
		
		weapons[]={"TIOW_THE_Braids"};
		requiredVersion=0.1;
		requiredAddons[]={"A3_Characters_F"};
	};
};

class cfgWeapons
{

        class ItemCore;

	class H_HelmetB: ItemCore
{
        class ItemInfo;
};

        class TIOW_THE_Braids: H_HelmetB
{

	author = "DBB";
	displayName  = "New Braids"; /// how would the stuff be displayed in inventory and on ground
	//picture = "\export_folder\Color_Texture.paa"; /// this looks fairly similar
	model   = "\export_folder\HairBraids.p3d"; /// what model does the cap use

        class ItemInfo: ItemInfo
	{	mass = 2;
		uniformModel = "\export_folder\HairBraids.p3d";	/// what model is used for this cap	
	};
};	
	

};